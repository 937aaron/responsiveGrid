Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by pinkyfinger ( http://www.freesound.org/people/pinkyfinger/  )
You can find this pack online at: http://www.freesound.org/people/pinkyfinger/packs/4409/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 68448__pinkyfinger__Piano_G.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68448/
    * license: Creative Commons 0
  * 68447__pinkyfinger__Piano_G_.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68447/
    * license: Creative Commons 0
  * 68446__pinkyfinger__Piano_F.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68446/
    * license: Creative Commons 0
  * 68445__pinkyfinger__Piano_F_.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68445/
    * license: Creative Commons 0
  * 68444__pinkyfinger__Piano_Eb.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68444/
    * license: Creative Commons 0
  * 68443__pinkyfinger__Piano_E.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68443/
    * license: Creative Commons 0
  * 68442__pinkyfinger__Piano_D.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68442/
    * license: Creative Commons 0
  * 68441__pinkyfinger__Piano_C.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68441/
    * license: Creative Commons 0
  * 68440__pinkyfinger__Piano_C_.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68440/
    * license: Creative Commons 0
  * 68439__pinkyfinger__Piano_Bb.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68439/
    * license: Creative Commons 0
  * 68438__pinkyfinger__Piano_B.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68438/
    * license: Creative Commons 0
  * 68437__pinkyfinger__Piano_A.wav
    * url: http://www.freesound.org/people/pinkyfinger/sounds/68437/
    * license: Creative Commons 0

